﻿using doveShooter.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace doveShooter
{
  class BloodSplat : ImageBase
  {
    public BloodSplat()
      : base(Resources.bloodSplatter2)
    { 
    
    }
  }
}
